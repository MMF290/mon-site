// Message de bienvenue personnalisé sur la page d'accueil
document.addEventListener("DOMContentLoaded", function () {
  if (document.querySelector("h1") && document.title.includes("Accueil")) {
    alert("Bienvenue sur votre nouveau site web !");
  }

  // Confirmation lors de l'envoi du formulaire de contact
  const form = document.querySelector("form");
  if (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      alert("Merci pour votre message !");
      form.reset();
    });
  }
});
